#!/bin/bash

clear
echo -e "================================================="
echo -e "#     Premium Auto Script By Akbar Maulana      #"
echo -e "================================================="
echo -e "# For Debian 10 64 bit                          #"
echo -e "# For Ubuntu 18.04 & Ubuntu 20.04 64 bit        #"
echo -e "# For VPS with KVM and VMWare virtualization    #"
echo -e "# Build Up By Akbar Maulana                     #"
echo -e "================================================="
echo -e "# Thanks To                                     #"
echo -e "================================================="
echo -e "# Allah SWT                                     #"
echo -e "# My Family                                     #"
echo -e "# LamVpn                                        #"
echo -e "# Horasss                                       #"
echo -e "================================================="
